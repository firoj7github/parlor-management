<div class="copyright-wrapper">
    <div class="copyright-area">
        <p>Developed by <a href="https://appdevs.net">Appdevs.</a></p>
        <p>{{ $basic_settings->site_name }} <span>V{{ $basic_settings->web_version }}</span></p>
    </div>
</div>