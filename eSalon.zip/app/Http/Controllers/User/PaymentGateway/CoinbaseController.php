<?php

namespace App\Http\Controllers\User\PaymentGateway;

use Illuminate\Http\Request;
use CoinbaseCommerce\ApiClient;
use App\Http\Controllers\Controller;

class CoinbaseController extends Controller
{
    public function coinbasePayment(Request $request)
    {
       
        $apiClientObj = ApiClient::init();
        
    }
}
