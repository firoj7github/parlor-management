<?php

namespace App\Constants;

class SiteSectionConst{
    const SLIDER_SECTION            = "Slider";
    const HOW_ITS_WORK_SECTION      = "How Its Work";
    const TESTIMONIAL_SECTION       = "Testimonial";
    const STATISTIC_SECTION         = "Statistic";
    const DOWNLOAD_APP_SECTION      = "Download App";
    const PHOTO_GALLERY_SECTION     = "Photo Gallery";
    const FOOTER_SECTION            = "Footer";
    const CONTACT_SECTION           = "Contact";
    const ABOUT_SECTION             = "About";
    const FAQ_SECTION               = "Faq";
    const SERVICE_SECTION           = "Service";
    const BLOG_SECTION              = "Blog";

}